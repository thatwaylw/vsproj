﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
//using System.Collections.Generic;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string bg_fn = @"C:\Users\laiwei\Desktop\描红-黑.png";

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "haha哈";
            pictureBox1.ImageLocation = bg_fn;
            pictureBox1.Show();

            //#region 保存图片
            //Bitmap bmp = new Bitmap(pictureBox1.Image, pictureBox1.Width, pictureBox1.Height);
            //Graphics g = Graphics.FromImage(bmp);

            //bmp.Save("d://1.bmp", System.Drawing.Imaging.ImageFormat.Bmp);
            //#endregion

            miaohong = new Miaohong();
            miaohong.bihuas = new List<Bihua>();
            sta = 0;
            button7.Text = "轮廓";
            cur_bh = 0;
            numericUpDown1.Value = cur_bh;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            string x = e.X.ToString(); //x坐标
            string y = e.Y.ToString(); //Y坐标
            textBox1.Text = ("X:" + x + "  Y:" + y);

            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {// 但是，鼠标画上去的红点，取不到。。。取的还是白色
                Bitmap bmp = new Bitmap(pictureBox1.Image, pictureBox1.Width, pictureBox1.Height);
                Color color = bmp.GetPixel(e.X, e.Y);
                textBox1.Text = string.Format("{0},{1},{2}", color.R, color.G, color.B);
            }
            else
            {
                //Graphics g = ((PictureBox)sender).CreateGraphics();
                Graphics g = pictureBox1.CreateGraphics();

                Bihua bihua = null;
                if (cur_bh < miaohong.bihuas.Count)
                {
                    bihua = miaohong.bihuas[cur_bh];
                }
                else
                {
                    bihua = new Bihua();
                    bihua.lunkuo = new Lunkuo();
                    bihua.lunkuo.dots = new List<Dot>();
                    bihua.tiancong = new Tiancong();
                    bihua.tiancong.dotpairs = new List<DotPair>();
                    miaohong.bihuas.Add(bihua);
                }

                if (sta == 0)
                {
                    g.FillEllipse(Brushes.Red, e.X - 4, e.Y - 4, 8, 8);
                    bihua.lunkuo.dots.Add(new Dot(e.X, e.Y));
                }
                else
                {
                    g.FillEllipse(Brushes.Green, e.X - 2, e.Y - 2, 4, 4);
                }
                //Point pt = new Point(e.X-4, e.Y-4);
                g.Dispose();

                //one_dot(e.X, e.Y);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            Bitmap bmp = new Bitmap(pictureBox1.Image, pictureBox1.Width, pictureBox1.Height);
            for (int x = 0; x < pictureBox1.Width; x++)
            {
                for (int y = 0; y < pictureBox1.Height; y++)
                {
                    Color color = bmp.GetPixel(x, y);
                    if (color.R <= 200 && color.R >= 50)
                    {
                        g.FillEllipse(Brushes.Red, x, y, 2, 2);
                    }
                }
            }

            g.Dispose();

        }

        private string cur_fn;
        private Miaohong miaohong;
        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            //fdlg.Filter = "文本文件(*.txt)|*.txt";
            //fdlg.Title = "载入待标注文本文件";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                //textBox1.Text = fdlg.FileName;
                cur_fn = fdlg.FileName;
                miaohong = new Miaohong();
                miaohong.LoadfromFile(cur_fn);
                ShowMiaohong();
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            miaohong.SavetoFile();
        }

        

        private void ShowMiaohong()
        {
            Graphics g = pictureBox1.CreateGraphics();
            //g.Clear(Color.White);
            //pictureBox1.Show();

            int idx = 0;
            foreach (Bihua bihua in miaohong.bihuas)
            {
                foreach (Dot dot in bihua.lunkuo.dots)
                {
                    g.FillEllipse((sta==0 && cur_bh==idx) ? Brushes.Red : Brushes.Gray, dot.x - 4, dot.y - 4, 8, 8);
                }
                foreach(DotPair dotpair in bihua.tiancong.dotpairs)
                {
                    Pen gPen = new Pen((sta==1 && cur_bh==idx) ? Color.Green : Color.Gray, 1);
                    Point p1 = new Point (dotpair.d1.x, dotpair.d1.y);
                    Point p2 = new Point (dotpair.d2.x, dotpair.d2.y);
                    g.DrawLine(gPen, p1, p2);
                }
                idx++;
            }
            g.Dispose();
        }

        private int sta = 0;        // 0：笔画；1：填充
        private int cur_bh = 0;     // 当前第几画

        private void button4_Click(object sender, EventArgs e)
        {
            //Graphics g = pictureBox1.CreateGraphics();
            //g.Clear(Color.White);
            pictureBox1.ImageLocation = bg_fn;
            pictureBox1.Show();
            ShowMiaohong();

            //int ts = int.Parse(numericUpDown1.Value.ToString());
            //showFile(cur_fn, ts);
        }
        private void button5_Click(object sender, EventArgs e)
        {
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(sta==0)
            {
                sta = 1;
                button7.Text = "填充";
            }
            else
            {
                sta = 0;
                button7.Text = "轮廓";
            }
            ShowMiaohong();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            cur_bh = int.Parse(numericUpDown1.Value.ToString());
            if (cur_bh >= miaohong.bihuas.Count)
            {
                cur_bh = miaohong.bihuas.Count - 1;
                numericUpDown1.Value = cur_bh;
            }
            ShowMiaohong();
        }


       
    }
}
