﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Miaohong
    {
        public List<Bihua> bihuas;

        public void LoadfromFile(string fn)
        {
            string buf = File.ReadAllText(fn);
            buf = buf.Replace("\n", "").Replace("\r", "");
            bihuas = new List<Bihua>();

            int p1 = buf.IndexOf("\"frame\":[[[") + 10;
            int p2 = buf.IndexOf("]]]", p1);
            string frame = buf.Substring(p1, p2 - p1);

            p1 = buf.IndexOf("\"fill\":[[[") + 9;
            p2 = buf.IndexOf("]]]", p1);
            string fill = buf.Substring(p1, p2 - p1);

            for (int i = 0; i < 2; i++)
            {
                string ss = (i == 0) ? frame : fill;

                ss = ss.Replace("]],[[", "|");
                ss = ss.Replace("],[", ";");
                ss = ss.Replace("[", "").Replace("]", "").Replace(" ", "");

                int i_bihua = 0;
                foreach (string bihua in ss.Split('|'))
                {
                    Bihua n_bihua = (i == 0) ? (new Bihua()) : (i_bihua < bihuas.Count ? bihuas[i_bihua] : (new Bihua()));
                    if (i == 0)
                    {
                        n_bihua.lunkuo = new Lunkuo();
                        n_bihua.lunkuo.dots = new List<Dot>();
                    }
                    else
                    {
                        n_bihua.tiancong = new Tiancong();
                        n_bihua.tiancong.dotpairs = new List<DotPair>();
                    }

                    DotPair c_dotpair = null;
                    foreach (string ddot in bihua.Split(';'))
                    {
                        string[] tok = ddot.Split(',');
                        int x = int.Parse(tok[0]);
                        int y = int.Parse(tok[1]);

                        if (i == 0)
                        {
                            Dot n_dot = new Dot(x, y);
                            n_bihua.lunkuo.dots.Add(n_dot);
                        }
                        else
                        {
                            if (c_dotpair == null)
                            {
                                c_dotpair = new DotPair();
                                c_dotpair.d1 = new Dot(x, y);
                            }
                            else
                            {
                                c_dotpair.d2 = new Dot(x, y);
                                n_bihua.tiancong.dotpairs.Add(c_dotpair);
                                c_dotpair = null;
                            }
                        }

                    }
                    if(i==0)    bihuas.Add(n_bihua);
                    else
                    {
                        if (i_bihua < bihuas.Count) i_bihua++;
                        else bihuas.Add(n_bihua);
                    }
                }

            }
        }

        public void SavetoFile()
        {
            string buf = "{\"data\":[{\"pinyin\":\"a\",\"frame\":[\n";

            foreach (Bihua bihua in bihuas)
            {
                buf += "[";
                foreach (Dot dot in bihua.lunkuo.dots)
                {
                    buf += string.Format("[{0},{1}],", dot.x, dot.y);
                }
                if (bihua.lunkuo.dots.Count>0)
                {
                    buf = buf.Remove(buf.Length - 1);
                }
                buf += "],\n";
            }
            if (bihuas.Count>0) buf = buf.Remove(buf.Length - 2);
            buf += "],\n\"fill\":[\n";

            foreach (Bihua bihua in bihuas)
            {
                buf += "[";
                foreach (DotPair dotpair in bihua.tiancong.dotpairs)
                {
                    buf += string.Format("[{0},{1}],[{2},{3}],", dotpair.d1.x, dotpair.d1.y, dotpair.d2.x, dotpair.d2.y);
                }
                if (bihua.tiancong.dotpairs.Count > 0)
                {
                    buf = buf.Remove(buf.Length - 1);
                }
                buf += "],\n";
            }
            if (bihuas.Count > 0) buf = buf.Remove(buf.Length - 2);
            buf += "],\n\"word\":\"考\",\"bihuashu\":6,\"gif\":null,\"obushou\":\"丷\",\"bihua_mingcheng\":\"点,撇,竖\"}],\"result\":\"succ\"}";

            File.WriteAllText("result.txt", buf);
        }
    }
    

    class Bihua
    {
        public Lunkuo lunkuo;
        public Tiancong tiancong;
    }

    class Lunkuo
    {
        public List<Dot> dots;
    }
    class Tiancong
    {
        public List<DotPair> dotpairs;
    }

    class DotPair
    {
        public Dot d1;
        public Dot d2;
    }
    class Dot
    {
        public int x;
        public int y;
        public Dot(int x0, int y0)
        {
            x = x0;
            y = y0;
        }
    }
}
