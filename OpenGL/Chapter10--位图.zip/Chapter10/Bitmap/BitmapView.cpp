// BitmapView.cpp : implementation of the CBitmapView class
//

#include "stdafx.h"
#include "Bitmap.h"

#include "BitmapDoc.h"
#include "BitmapView.h"

//add down
#include "gl\gl.h"
#include "gl\glu.h"
#include "gl\glaux.h"
//add up

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//add down�ַ�Fλͼ����Ӧ����
GLubyte rasters[24]=
{
	0xc0,0x00,0xc0,0x00,0xc0,0x00,0xc0,0x00,
	0xc0,0x00,0xff,0x00,0xff,0x00,0xc0,0x00,
	0xc0,0x00,0xc0,0x00,0xff,0xc0,0xff,0xc0
};
//add up�ַ�Fλͼ����Ӧ����
/////////////////////////////////////////////////////////////////////////////
// CBitmapView

IMPLEMENT_DYNCREATE(CBitmapView, CView)

BEGIN_MESSAGE_MAP(CBitmapView, CView)
	//{{AFX_MSG_MAP(CBitmapView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBitmapView construction/destruction

CBitmapView::CBitmapView()
{
	//add down
	m_pDC = NULL;
	//add up
}

CBitmapView::~CBitmapView()
{
}

BOOL CBitmapView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	//add down
	cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
	//add up

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapView drawing

void CBitmapView::OnDraw(CDC* pDC)
{
	CBitmapDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	//add down
	DrawScene();
	//add up
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapView printing

BOOL CBitmapView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CBitmapView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CBitmapView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapView diagnostics

#ifdef _DEBUG
void CBitmapView::AssertValid() const
{
	CView::AssertValid();
}

void CBitmapView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CBitmapDoc* CBitmapView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBitmapDoc)));
	return (CBitmapDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBitmapView message handlers

int CBitmapView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	//add down
	Init(); //��ʼ��OpenGL
	//add up
	
	return 0;
}

void CBitmapView::OnDestroy() 
{
	//add down
	HGLRC   hrc;

	hrc = ::wglGetCurrentContext();

	::wglMakeCurrent(NULL,  NULL);

	if (hrc)
		::wglDeleteContext(hrc);

	if (m_pDC)
		delete m_pDC;
	//add up

	CView::OnDestroy();
}

BOOL CBitmapView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

void CBitmapView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	GLfloat w=(GLfloat)cx;
	GLfloat h=(GLfloat)cy;
	//�����ӿ��봰��ƥ��
	glViewport(0,0,w,h);

	//������������ϵͳ
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	//���������任�µļ�����
	glOrtho(0,w,0,h,-1.0,1.0);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//add up
}

//add down
void CBitmapView::Init()
{
	PIXELFORMATDESCRIPTOR pfd;
	int         n;
	HGLRC       hrc;

	m_pDC = new CClientDC(this);

	ASSERT(m_pDC != NULL);

	if (!bSetupPixelFormat())
		return;

	n = ::GetPixelFormat(m_pDC->GetSafeHdc());
	::DescribePixelFormat(m_pDC->GetSafeHdc(), n, sizeof(pfd), &pfd);

	hrc = wglCreateContext(m_pDC->GetSafeHdc());
	wglMakeCurrent(m_pDC->GetSafeHdc(), hrc);

	//���ݿͻ����ĳ�ʼֵ��͸��ͶӰ
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);

	//�������ش洢ģʽΪGL_UNPACK_ALIGNMENT
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
	//����Ļ��ʼֵ��Ϊ��ɫ
	glClearColor(0.0,0.0,0.0,0.0);
}

BOOL CBitmapView::bSetupPixelFormat()
{
	static PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
		1,                              // version number
		PFD_DRAW_TO_WINDOW |            // support window
		  PFD_SUPPORT_OPENGL |          // support OpenGL
		  PFD_DOUBLEBUFFER,             // double buffered
		PFD_TYPE_RGBA,                  // RGBA type
		24,                             // 24-bit color depth
		0, 0, 0, 0, 0, 0,               // color bits ignored
		0,                              // no alpha buffer
		0,                              // shift bit ignored
		0,                              // no accumulation buffer
		0, 0, 0, 0,                     // accum bits ignored
		32,                             // 32-bit z-buffer
		0,                              // no stencil buffer
		0,                              // no auxiliary buffer
		PFD_MAIN_PLANE,                 // main layer
		0,                              // reserved
		0, 0, 0                         // layer masks ignored
	};
	int pixelformat;

	if ( (pixelformat = ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd)) == 0 )
	{
		MessageBox("ChoosePixelFormat failed");
		return FALSE;
	}

	if (SetPixelFormat(m_pDC->GetSafeHdc(), pixelformat, &pfd) == FALSE)
	{
		MessageBox("SetPixelFormat failed");
		return FALSE;
	}

	return TRUE;
}

void CBitmapView::DrawScene(void)
{
	//����������ɫΪ��ɫ
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	//�����ɫ����������Ȼ�����
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//����ͼ����ɫΪ��ɫ
	glColor3f(1.0,1.0,1.0);
	//��������λ��
	glRasterPos2i(20.5,20.5);
	//����ͼ��
	glBitmap(10,12,0.0,0.0,12.0,0.0,rasters);
	glBitmap(10,12,0.0,0.0,12.0,0.0,rasters);
	glBitmap(10,12,0.0,0.0,12.0,0.0,rasters);

	glFinish();
	SwapBuffers(wglGetCurrentDC());
}

