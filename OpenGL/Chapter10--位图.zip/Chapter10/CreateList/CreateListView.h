// CreateListView.h : interface of the CCreateListView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CREATELISTVIEW_H__440AF14D_787B_11D3_ACC9_0080C8EBAE24__INCLUDED_)
#define AFX_CREATELISTVIEW_H__440AF14D_787B_11D3_ACC9_0080C8EBAE24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CCreateListView : public CView
{
protected: // create from serialization only
	CCreateListView();
	DECLARE_DYNCREATE(CCreateListView)

// Attributes
public:
	CCreateListDoc* GetDocument();

	//add down
	CClientDC   *m_pDC;

// Operations
public:
	void Init();
	BOOL bSetupPixelFormat(void);
	void DrawScene(void);
	//add up
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateListView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCreateListView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CCreateListView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in CreateListView.cpp
inline CCreateListDoc* CCreateListView::GetDocument()
   { return (CCreateListDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATELISTVIEW_H__440AF14D_787B_11D3_ACC9_0080C8EBAE24__INCLUDED_)
