// CreateListView.cpp : implementation of the CCreateListView class
//

#include "stdafx.h"
#include "CreateList.h"

#include "CreateListDoc.h"
#include "CreateListView.h"

//add down
#include "gl\gl.h"
#include "gl\glu.h"
#include "gl\glaux.h"

GLuint listName=1;
//add up

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCreateListView

IMPLEMENT_DYNCREATE(CCreateListView, CView)

BEGIN_MESSAGE_MAP(CCreateListView, CView)
	//{{AFX_MSG_MAP(CCreateListView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCreateListView construction/destruction

CCreateListView::CCreateListView()
{
	//add down
	m_pDC = NULL;
	//add up
}

CCreateListView::~CCreateListView()
{
}

BOOL CCreateListView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	//add down
	cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
	//add up

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CCreateListView drawing

void CCreateListView::OnDraw(CDC* pDC)
{
	CCreateListDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	//add down
	DrawScene();
	//add up
}

/////////////////////////////////////////////////////////////////////////////
// CCreateListView printing

BOOL CCreateListView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CCreateListView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CCreateListView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CCreateListView diagnostics

#ifdef _DEBUG
void CCreateListView::AssertValid() const
{
	CView::AssertValid();
}

void CCreateListView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCreateListDoc* CCreateListView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCreateListDoc)));
	return (CCreateListDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCreateListView message handlers

int CCreateListView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	//add down
	Init(); //��ʼ��OpenGL
	//add up
	
	return 0;
}

void CCreateListView::OnDestroy() 
{
	//add down
	HGLRC   hrc;

	hrc = ::wglGetCurrentContext();

	::wglMakeCurrent(NULL,  NULL);

	if (hrc)
		::wglDeleteContext(hrc);

	if (m_pDC)
		delete m_pDC;
	//add up

	CView::OnDestroy();
}

BOOL CCreateListView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

void CCreateListView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	//add down
	int w=cx;
	int h=cy;
	//�������Ϊ0
	if(h==0) h=1;

	//�����ӿ��봰��ƥ��
	glViewport(0,0,w,h);

	//������������ϵͳ
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	//���������任�µļ�����
	if(w<h)
		gluOrtho2D(0.0,2.0,-0.5*(GLfloat)h/(GLfloat)w,1.5*(GLfloat)h/(GLfloat)w);
	else
		gluOrtho2D(0.0,2.0*(GLfloat)w/(GLfloat)h,-0.5,1.5);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//add up
}

//add down
void CCreateListView::Init()
{
	PIXELFORMATDESCRIPTOR pfd;
	int         n;
	HGLRC       hrc;

	m_pDC = new CClientDC(this);

	ASSERT(m_pDC != NULL);

	if (!bSetupPixelFormat())
		return;

	n = ::GetPixelFormat(m_pDC->GetSafeHdc());
	::DescribePixelFormat(m_pDC->GetSafeHdc(), n, sizeof(pfd), &pfd);

	hrc = wglCreateContext(m_pDC->GetSafeHdc());
	wglMakeCurrent(m_pDC->GetSafeHdc(), hrc);

	//���ݿͻ����ĳ�ʼֵ��͸��ͶӰ
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);

	//��glNewList()��glEndList()������ʾ�б��Ŀ�ʼ�ͽ���
	//����������
	glNewList(listName,GL_COMPILE);
		glColor3f(1.0,0.0,0.0);
		glBegin(GL_TRIANGLES);
			glVertex2f(0.0,0.0);
			glVertex2f(1.0,0.0);
			glVertex2f(0.0,1.0);
		glEnd();
	//�����ı�Ҫ���Ƶ���һ�������ε�λ��
		glTranslatef(1.5,0.0,0.0);
	glEndList();
	
	glShadeModel(GL_FLAT);
}

BOOL CCreateListView::bSetupPixelFormat()
{
	static PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
		1,                              // version number
		PFD_DRAW_TO_WINDOW |            // support window
		  PFD_SUPPORT_OPENGL |          // support OpenGL
		  PFD_DOUBLEBUFFER,             // double buffered
		PFD_TYPE_RGBA,                  // RGBA type
		24,                             // 24-bit color depth
		0, 0, 0, 0, 0, 0,               // color bits ignored
		0,                              // no alpha buffer
		0,                              // shift bit ignored
		0,                              // no accumulation buffer
		0, 0, 0, 0,                     // accum bits ignored
		32,                             // 32-bit z-buffer
		0,                              // no stencil buffer
		0,                              // no auxiliary buffer
		PFD_MAIN_PLANE,                 // main layer
		0,                              // reserved
		0, 0, 0                         // layer masks ignored
	};
	int pixelformat;

	if ( (pixelformat = ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd)) == 0 )
	{
		MessageBox("ChoosePixelFormat failed");
		return FALSE;
	}

	if (SetPixelFormat(m_pDC->GetSafeHdc(), pixelformat, &pfd) == FALSE)
	{
		MessageBox("SetPixelFormat failed");
		return FALSE;
	}

	return TRUE;
}

void CCreateListView::DrawScene(void)
{
	GLuint i;
	//�����ɫ����������Ȼ�����
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glColor3f(0.0,1.0,0.0);
	//ͨ��ʶ���������б�����������glCallList()���м��
	//����ʮ��������
	for(i=0;i<10;i++)
		glCallList(listName);
	
	//�����߶�
	glBegin(GL_LINES);
		glVertex2f(0.0,0.5);
		glVertex2f(15.0,0.5);
	glEnd();

	glFinish();
	SwapBuffers(wglGetCurrentDC());
}


//add up

