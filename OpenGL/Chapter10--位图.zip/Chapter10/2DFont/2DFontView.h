// 2DFontView.h : interface of the CMy2DFontView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_2DFONTVIEW_H__0BCB5A6D_789A_11D3_ACC9_0080C8EBAE24__INCLUDED_)
#define AFX_2DFONTVIEW_H__0BCB5A6D_789A_11D3_ACC9_0080C8EBAE24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//add down
#include "gl\gl.h"
#include "gl\glu.h"
#include "gl\glaux.h"
//add up

class CMy2DFontView : public CView
{
protected: // create from serialization only
	CMy2DFontView();
	DECLARE_DYNCREATE(CMy2DFontView)

// Attributes
public:
	CMy2DFontDoc* GetDocument();

	//add down
	CClientDC   *m_pDC;
	GLint m_LastDisplayListID;
// Operations
public:
	void Init();
	BOOL bSetupPixelFormat(void);
	void DrawScene(void);
protected:
	GLuint m_DefaultFlatTextID;
	// The Font Member Functions
	virtual void	SetDefaultFonts( char* font3D = 
		"Ariel", char* fontFlat ="Ariel")
		{ GenerateDefaultFonts( font3D, fontFlat ); }
	void	GLTextOut( GLuint id, const char * const textstring );
	GLuint	GenerateBitmapListForFont( char* fontname );
	// The Display List & Stock Scene Management
	// Member Functions
	static GLuint	GetNewDisplayListIDs( GLsizei range );
	static GLuint	GetNewDisplayListID()
		{ return GetNewDisplayListIDs( (unsigned int)1 ); }
	void	GenerateDefaultFonts( char*, char* );
	//add up

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy2DFontView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMy2DFontView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMy2DFontView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in 2DFontView.cpp
inline CMy2DFontDoc* CMy2DFontView::GetDocument()
   { return (CMy2DFontDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_2DFONTVIEW_H__0BCB5A6D_789A_11D3_ACC9_0080C8EBAE24__INCLUDED_)
