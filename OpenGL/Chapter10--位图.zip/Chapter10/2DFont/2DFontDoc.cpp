// 2DFontDoc.cpp : implementation of the CMy2DFontDoc class
//

#include "stdafx.h"
#include "2DFont.h"

#include "2DFontDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMy2DFontDoc

IMPLEMENT_DYNCREATE(CMy2DFontDoc, CDocument)

BEGIN_MESSAGE_MAP(CMy2DFontDoc, CDocument)
	//{{AFX_MSG_MAP(CMy2DFontDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy2DFontDoc construction/destruction

CMy2DFontDoc::CMy2DFontDoc()
{
	// TODO: add one-time construction code here

}

CMy2DFontDoc::~CMy2DFontDoc()
{
}

BOOL CMy2DFontDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMy2DFontDoc serialization

void CMy2DFontDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMy2DFontDoc diagnostics

#ifdef _DEBUG
void CMy2DFontDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMy2DFontDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMy2DFontDoc commands
