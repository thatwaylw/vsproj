// WrapView.h : interface of the CWrapView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_WRAPVIEW_H__1E71769F_807A_11D3_9970_0000E8668E8F__INCLUDED_)
#define AFX_WRAPVIEW_H__1E71769F_807A_11D3_9970_0000E8668E8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CWrapView : public CView
{
protected: // create from serialization only
	CWrapView();
	DECLARE_DYNCREATE(CWrapView)

// Attributes
public:
	CWrapDoc* GetDocument();

	//add down
	CClientDC   *m_pDC;

// Operations
public:
	void Init();
	BOOL bSetupPixelFormat(void);
	void DrawScene(void);
	//add up
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWrapView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWrapView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWrapView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in WrapView.cpp
inline CWrapDoc* CWrapView::GetDocument()
   { return (CWrapDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WRAPVIEW_H__1E71769F_807A_11D3_9970_0000E8668E8F__INCLUDED_)
