// WrapDoc.cpp : implementation of the CWrapDoc class
//

#include "stdafx.h"
#include "Wrap.h"

#include "WrapDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWrapDoc

IMPLEMENT_DYNCREATE(CWrapDoc, CDocument)

BEGIN_MESSAGE_MAP(CWrapDoc, CDocument)
	//{{AFX_MSG_MAP(CWrapDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWrapDoc construction/destruction

CWrapDoc::CWrapDoc()
{
	// TODO: add one-time construction code here

}

CWrapDoc::~CWrapDoc()
{
}

BOOL CWrapDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CWrapDoc serialization

void CWrapDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CWrapDoc diagnostics

#ifdef _DEBUG
void CWrapDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CWrapDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWrapDoc commands
