// TexBindDoc.h : interface of the CTexBindDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXBINDDOC_H__1E71764B_807A_11D3_9970_0000E8668E8F__INCLUDED_)
#define AFX_TEXBINDDOC_H__1E71764B_807A_11D3_9970_0000E8668E8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTexBindDoc : public CDocument
{
protected: // create from serialization only
	CTexBindDoc();
	DECLARE_DYNCREATE(CTexBindDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTexBindDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTexBindDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTexBindDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXBINDDOC_H__1E71764B_807A_11D3_9970_0000E8668E8F__INCLUDED_)
