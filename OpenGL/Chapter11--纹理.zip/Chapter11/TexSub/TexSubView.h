// TexSubView.h : interface of the CTexSubView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXSUBVIEW_H__1E71768B_807A_11D3_9970_0000E8668E8F__INCLUDED_)
#define AFX_TEXSUBVIEW_H__1E71768B_807A_11D3_9970_0000E8668E8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTexSubView : public CView
{
protected: // create from serialization only
	CTexSubView();
	DECLARE_DYNCREATE(CTexSubView)

// Attributes
public:
	CTexSubDoc* GetDocument();

	//add down
	CClientDC   *m_pDC;

// Operations
public:
	void Init();
	BOOL bSetupPixelFormat(void);
	void DrawScene(void);
	//add up
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTexSubView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTexSubView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTexSubView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TexSubView.cpp
inline CTexSubDoc* CTexSubView::GetDocument()
   { return (CTexSubDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXSUBVIEW_H__1E71768B_807A_11D3_9970_0000E8668E8F__INCLUDED_)
