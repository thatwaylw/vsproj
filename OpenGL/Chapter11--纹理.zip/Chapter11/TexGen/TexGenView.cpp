// TexGenView.cpp : implementation of the CTexGenView class
//

#include "stdafx.h"
#include "TexGen.h"

#include "TexGenDoc.h"
#include "TexGenView.h"

//add down 
#include "gl\gl.h"
#include "gl\glu.h"
#include "gl\glaux.h"

#include <stdlib.h>
#include <stdio.h>
//add up

//add down
#define	stripeImageWidth 32
GLubyte stripeImage[4*stripeImageWidth];
//add up

//add down
/*�����������ɵ�ƽ��*/
static GLfloat xequalzero[] = {1.0, 0.0, 0.0, 0.0};
static GLfloat slanted[] = {1.0, 1.0, 1.0, 0.0};
static GLfloat *currentCoeff;
static GLenum currentPlane;
static GLint currentGenMode;
//add up

//add down
//���OpenGL�İ汾��Ϊ1.1,�������
#ifdef GL_VERSION_1_1
static GLuint texName;
#endif
//add up

//add down
//��������
void makeStripeImage(void);
//add up

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTexGenView

IMPLEMENT_DYNCREATE(CTexGenView, CView)

BEGIN_MESSAGE_MAP(CTexGenView, CView)
	//{{AFX_MSG_MAP(CTexGenView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTexGenView construction/destruction

CTexGenView::CTexGenView()
{
	//add dowm
	m_pDC = NULL;
	//add up
}

CTexGenView::~CTexGenView()
{
}

BOOL CTexGenView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	//add down
	cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
	//add up

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTexGenView drawing

void CTexGenView::OnDraw(CDC* pDC)
{
	CTexGenDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	//add down
	DrawScene();
	//add up
}

/////////////////////////////////////////////////////////////////////////////
// CTexGenView printing

BOOL CTexGenView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTexGenView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTexGenView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTexGenView diagnostics

#ifdef _DEBUG
void CTexGenView::AssertValid() const
{
	CView::AssertValid();
}

void CTexGenView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTexGenDoc* CTexGenView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTexGenDoc)));
	return (CTexGenDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTexGenView message handlers

int CTexGenView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	//add down
	Init(); // initialize OpenGL
	//add up
	
	return 0;
}

void CTexGenView::OnDestroy() 
{
	//add down
	HGLRC   hrc;

	hrc = ::wglGetCurrentContext();

	::wglMakeCurrent(NULL,  NULL);

	if (hrc)
		::wglDeleteContext(hrc);

	if (m_pDC)
		delete m_pDC;
	//add up

	CView::OnDestroy();
}

BOOL CTexGenView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

void CTexGenView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	//add down
	if(cy > 0)
	{
		glViewport(0, 0, cx, cy);

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		//����Ϊ��ͶӰ
		if (cx <= cy)
			glOrtho (-3.5, 3.5, -3.5*(GLfloat)cy/(GLfloat)cx, 
			       3.5*(GLfloat)cy/(GLfloat)cx ,-3.5, 3.5);
		else
			glOrtho (-3.5*(GLfloat)cx/(GLfloat)cy, 
				   3.5*(GLfloat)cx/(GLfloat)cy, -3.5, 3.5, -3.5, 3.5);
		glMatrixMode(GL_MODELVIEW);
	}
	//add up
}

//add down
void CTexGenView::Init()
{
	PIXELFORMATDESCRIPTOR pfd;
	int         n;
	HGLRC       hrc;

	m_pDC = new CClientDC(this);

	ASSERT(m_pDC != NULL);

	if (!bSetupPixelFormat())
		return;

	n = ::GetPixelFormat(m_pDC->GetSafeHdc());
	::DescribePixelFormat(m_pDC->GetSafeHdc(), n, sizeof(pfd), &pfd);

	hrc = wglCreateContext(m_pDC->GetSafeHdc());
	wglMakeCurrent(m_pDC->GetSafeHdc(), hrc);

	//������Ļ�ĳ�ʼ��ɫΪ��ɫ
   glClearColor (1.0, 1.0, 1.0, 0.0);
   //������ȼ����Ч
   glEnable(GL_DEPTH_TEST);
   //����ͼ�ι⻬
   glShadeModel(GL_SMOOTH);

   makeStripeImage();
   glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

#ifdef GL_VERSION_1_1
   glGenTextures(1, &texName);
   glBindTexture(GL_TEXTURE_1D, texName);
#endif
   glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
#ifdef GL_VERSION_1_1
   glTexImage1D(GL_TEXTURE_1D, 0, GL_RGBA, stripeImageWidth, 0,
                GL_RGBA, GL_UNSIGNED_BYTE, stripeImage);
#else
   glTexImage1D(GL_TEXTURE_1D, 0, 4, stripeImageWidth, 0,
                GL_RGBA, GL_UNSIGNED_BYTE, stripeImage);
#endif

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
   currentCoeff = xequalzero;
   currentGenMode = GL_OBJECT_LINEAR;
   currentPlane = GL_OBJECT_PLANE;
   glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, currentGenMode);
   glTexGenfv(GL_S, currentPlane, currentCoeff);

   glEnable(GL_TEXTURE_GEN_S);
   glEnable(GL_TEXTURE_1D);
   glEnable(GL_CULL_FACE);
   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);
   glEnable(GL_AUTO_NORMAL);
   glEnable(GL_NORMALIZE);
   glFrontFace(GL_CW);
   glCullFace(GL_BACK);
   glMaterialf (GL_FRONT, GL_SHININESS, 64.0);
}

BOOL CTexGenView::bSetupPixelFormat()
{
	static PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
		1,                              // version number
		PFD_DRAW_TO_WINDOW |            // support window
		  PFD_SUPPORT_OPENGL |          // support OpenGL
		  PFD_DOUBLEBUFFER,             // double buffered
		PFD_TYPE_RGBA,                  // RGBA type
		24,                             // 24-bit color depth
		0, 0, 0, 0, 0, 0,               // color bits ignored
		0,                              // no alpha buffer
		0,                              // shift bit ignored
		0,                              // no accumulation buffer
		0, 0, 0, 0,                     // accum bits ignored
		32,                             // 32-bit z-buffer
		0,                              // no stencil buffer
		0,                              // no auxiliary buffer
		PFD_MAIN_PLANE,                 // main layer
		0,                              // reserved
		0, 0, 0                         // layer masks ignored
	};
	int pixelformat;

	if ( (pixelformat = ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd)) == 0 )
	{
		MessageBox("ChoosePixelFormat failed");
		return FALSE;
	}

	if (SetPixelFormat(m_pDC->GetSafeHdc(), pixelformat, &pfd) == FALSE)
	{
		MessageBox("SetPixelFormat failed");
		return FALSE;
	}

	return TRUE;
}

void CTexGenView::DrawScene(void)
{
	//����ʼ�ı���ɫ����Ϊ��ɫ
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	//�����ɫ�������Ȼ���
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   glPushMatrix ();
   glRotatef(45.0, 0.0, 0.0, 1.0);
#ifdef GL_VERSION_1_1
   glBindTexture(GL_TEXTURE_1D, texName);
#endif
   auxSolidTeapot(2.0);
   glPopMatrix ();

	glFinish();
	SwapBuffers(wglGetCurrentDC());
}

void makeStripeImage(void)
{
   int j;
    
   for (j = 0; j < stripeImageWidth; j++) {
      stripeImage[4*j] = (GLubyte) ((j<=4) ? 255 : 0);
      stripeImage[4*j+1] = (GLubyte) ((j>4) ? 255 : 0);
      stripeImage[4*j+2] = (GLubyte) 0;
      stripeImage[4*j+3] = (GLubyte) 255;
   }
}
//add up