// TexGen.h : main header file for the TEXGEN application
//

#if !defined(AFX_TEXGEN_H__1E71766F_807A_11D3_9970_0000E8668E8F__INCLUDED_)
#define AFX_TEXGEN_H__1E71766F_807A_11D3_9970_0000E8668E8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTexGenApp:
// See TexGen.cpp for the implementation of this class
//

class CTexGenApp : public CWinApp
{
public:
	CTexGenApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTexGenApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTexGenApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXGEN_H__1E71766F_807A_11D3_9970_0000E8668E8F__INCLUDED_)
