﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Net;
using System.IO;
using System.Collections.Generic;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ZuoWenDemo
{
    public partial class Form1 : Form
    {

        Dictionary<string, string> dic_yaosu = new Dictionary<string, string>();
        Dictionary<string, string> dic_yaosu2 = new Dictionary<string, string>();

        public Form1()
        {
            InitializeComponent();
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;

            string[] Yaosu_buf = File.ReadAllLines("yaosu.txt");
            foreach (string lin in Yaosu_buf)
            {
                string[] tok = lin.Split('\t');
                string key = tok[0] + "_" + tok[1] + "_" + tok[2];
                string yaosu = tok[3];
                string yaosu2 = tok[4];
                dic_yaosu.Add(key, yaosu);
                dic_yaosu2.Add(key, yaosu2);
            }

            string default_key = "状物-动物_一二年级_习性特点";
            string default_yaosu = dic_yaosu[default_key];
            string default_yaosu2 = dic_yaosu2[default_key];

            foreach(string yaosu in parseYaoSu(default_yaosu))
            {
                cLB_YaoSu.Items.Add(yaosu);
            }

            foreach (string yaosu in parseYaoSu(default_yaosu2))
            {
                cLB_YaoSu2.Items.Add(yaosu);
            }
            
        }

        private string [] parseYaoSu(string buf)
        {
            buf = buf.Replace("】【", "|");
            buf = buf.Replace("【", "");
            buf = buf.Replace("】", "");

            return buf.Split('|');
        }
        JArray g_nlist = null;

        private void btn_Load_Click(object sender, EventArgs e)
        {
            /*
            cLB_YaoSu.ClearSelected();
            for (int j = 0; j < cLB_YaoSu.Items.Count; j++)
                cLB_YaoSu.SetItemChecked(j, false);
            cLB_YaoSu2.ClearSelected();
            for (int j = 0; j < cLB_YaoSu2.Items.Count; j++)
                cLB_YaoSu2.SetItemChecked(j, false);
            */
            RefreshYaosuList();

            string key = comboBox1.Text + "-" + comboBox2.Text + "_" + comboBox3.Text + "_" + comboBox4.Text;

            String url = "http://192.168.0.42:18082/qa_child/child_app/?toyId=9test50m&smode=ncourse-cnzuowen&t="+ tB_input.Text
                +"&sendpara=zuowen-cate&sendvalue=" + key;

            WebRequest request = WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding("utf-8"));
            //textBox1.Text = reader.ReadToEnd();
            String json = reader.ReadToEnd();
            //rTBox1.Text = json;
            //return;

            /*
            string jsonText = "{\"zone\":\"海淀\",\"zone_en\":\"haidian\"}";
            JObject jo = (JObject)JsonConvert.DeserializeObject(jsonText);
            string zone = jo["zone"].ToString();
            string zone_en = jo["zone_en"].ToString();   --*/

            JObject jo = (JObject)JsonConvert.DeserializeObject(json);
            JArray nlist = (JArray)jo["ncourse-list"];
            if (nlist == null)
                return;

            g_nlist = nlist;

            //tB_result.Text = "";
            //cLB_YaoSu.Items.Clear();

            rTBox1.Text = "";

            int n = nlist.Count;
            for (int i = 0; i < n; i++)
            {
                if (nlist[i]["content"] == null)
                {
                    //tB_result.Text += nlist[i]["id"].ToString() + ": " + nlist[i]["name"].ToString() + "\r\n";
                    rTBox1.Text += nlist[i]["name"].ToString() + ": " + nlist[i]["flag"].ToString() + ": " + nlist[i]["keys"].ToString() + ": " + nlist[i]["ids"].ToString() + "\r\n";
                    //cLB_YaoSu.Items.Add(nlist[i]["ids"].ToString() + ": " + nlist[i]["name"].ToString() + ": " + nlist[i]["flag"].ToString() + ": " + nlist[i]["keys"].ToString());
                }
                else
                {
                    rTBox1.Text += nlist[i]["name"].ToString() + ": " + nlist[i]["flag"].ToString() + ": \r\n";
                    JArray clist = (JArray)nlist[i]["content"];
                    int k = clist.Count;
                    for(int j=0; j<k; j++)
                    {
                        rTBox1.Text += "\t——" + clist[j]["keys"].ToString() + ": " + clist[j]["ids"].ToString() + "\r\n";
                    }
                }

                string[] tok = nlist[i]["flag"].ToString().Split('_');

                if (tok[1] == "无" || tok[1] == "不确定")
                    continue;

                if (tok[0] == "基础")
                {
                    for (int j = 0; j < cLB_YaoSu.Items.Count; j++)
                    {
                        if (cLB_YaoSu.Items[j].ToString() == nlist[i]["name"].ToString())
                        {
                            cLB_YaoSu.SetItemChecked(j, true);
                            cLB_YaoSu.Items[j] = nlist[i]["name"].ToString() + "(" + tok[1] + ")";
                        }
                    }
                }
                if (tok[0] == "优秀")
                {
                    for (int j = 0; j < cLB_YaoSu2.Items.Count; j++)
                    {
                        if (cLB_YaoSu2.Items[j].ToString() == nlist[i]["name"].ToString())
                        {
                            cLB_YaoSu2.SetItemChecked(j, true);
                            cLB_YaoSu2.Items[j] = nlist[i]["name"].ToString() + "(" + tok[1] + ")";
                        }
                    }
                }
            }
            
               
        }

        private void RefreshYaosuList()
        {
            cLB_YaoSu.Items.Clear();
            cLB_YaoSu2.Items.Clear();

            string key = comboBox1.Text + "-" + comboBox2.Text + "_" + comboBox3.Text + "_" + comboBox4.Text;

            if (!dic_yaosu.ContainsKey(key))
            {
                MessageBox.Show("暂不支持的组合！");
                return;

            }

            string yaosu1 = dic_yaosu[key];
            string yaosu2 = dic_yaosu2[key];

            foreach (string yaosu in parseYaoSu(yaosu1))
            {
                cLB_YaoSu.Items.Add(yaosu);
            }

            foreach (string yaosu in parseYaoSu(yaosu2))
            {
                cLB_YaoSu2.Items.Add(yaosu);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int i_nianji = comboBox3.SelectedIndex;
            RefreshYaosuList();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshYaosuList();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshYaosuList();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshYaosuList();
        }

        private void showRichText(string keys, string ids, string sent)
        {
            //rTBox1.Clear();

            if (keys.Length <= 0 || ids.Length <= 0)
                return;

            string[] tok = keys.Split('_');
            string[] pos = ids.Split('_');

            if (tok.Length <= 0 || pos.Length <= 2)
                return;

            int ss = Int32.Parse(pos[0])/3;
            int ee = Int32.Parse(pos[pos.Length-1])/3;
            int pp = ss;

            //rTBox1.SelectionColor = Color.Black;
            rTBox1.AppendText(sent.Substring(0, ss));
            rTBox1.AppendText("【【【");
            //rTBox1.AppendText(sent.Substring(ss, ee - ss));
            for (int i = 1; i < pos.Length-1; i++ )
            {
                int ii = Int32.Parse(pos[i])/3;
                rTBox1.SelectionColor = Color.Black;
                rTBox1.AppendText(sent.Substring(pp, ii - pp));
                rTBox1.SelectionColor = Color.Red;
                rTBox1.AppendText(tok[i - 1]);
                pp = ii + tok[i - 1].Length;
            }
            rTBox1.SelectionColor = Color.Black;
            rTBox1.AppendText(sent.Substring(pp, ee - pp));
            rTBox1.AppendText("】】】");
            rTBox1.AppendText(sent.Substring(ee));
        }

        private void analyseYaosu(string type, string yaosuname)
        {
            int n = g_nlist.Count;
            for (int i = 0; i < n; i++)
            {
                if (g_nlist[i]["flag"].ToString().Contains(type) && yaosuname.StartsWith(g_nlist[i]["name"].ToString()))
                {
                    if (g_nlist[i]["content"] == null)
                    {
                        //rTBox1.Text = g_nlist[i]["keys"].ToString() + "\r\n\r\n" + g_nlist[i]["ids"].ToString();
                        showRichText(g_nlist[i]["keys"].ToString(), g_nlist[i]["ids"].ToString(), tB_input.Text);
                    }
                    else
                    {
                        JArray clist = (JArray)g_nlist[i]["content"];
                        int k = clist.Count;
                        for (int j = 0; j < k; j++)
                        {
                            showRichText(clist[j]["keys"].ToString(), clist[j]["ids"].ToString(), tB_input.Text);
                            rTBox1.AppendText("\r\n——————————————————————\r\n");
                        }
                    }
                    break;
                }
            }
        }

        private void cLB_YaoSu_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (g_nlist == null) return;
            rTBox1.Clear();
            //int idx = cLB_YaoSu.SelectedIndex;
            string yaosuname = cLB_YaoSu.SelectedItem.ToString();
            analyseYaosu("基础", yaosuname);

            /*
            int n = g_nlist.Count;
            for (int i = 0; i < n; i++)
            {
                if (g_nlist[i]["flag"].ToString().Contains("基础") && yaosuname.StartsWith(g_nlist[i]["name"].ToString()))
                {
                    //rTBox1.Text = g_nlist[i]["keys"].ToString() + "\r\n\r\n" + g_nlist[i]["ids"].ToString();
                    showRichText(g_nlist[i]["keys"].ToString(), g_nlist[i]["ids"].ToString(), tB_input.Text);
                    break;
                }
            }
            */
            //textBox1.Text = yaosuname;
        }

        private void cLB_YaoSu2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (g_nlist == null) return;
            rTBox1.Clear();
            string yaosuname = cLB_YaoSu2.SelectedItem.ToString();
            analyseYaosu("优秀", yaosuname);

            /*
            int n = g_nlist.Count;
            for (int i = 0; i < n; i++)
            {
                if (g_nlist[i]["flag"].ToString().Contains("优秀") && yaosuname.StartsWith(g_nlist[i]["name"].ToString()))
                {
                    //rTBox1.Text = g_nlist[i]["keys"].ToString() + "\r\n\r\n" + g_nlist[i]["ids"].ToString();
                    showRichText(g_nlist[i]["keys"].ToString(), g_nlist[i]["ids"].ToString(), tB_input.Text);
                    break;
                }
            }
             * */
        }


               
    }
}
